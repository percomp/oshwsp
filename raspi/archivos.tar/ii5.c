/****************************************************************************
 * ii5c.c Configuración y lectura de datos del dispositivo de sensores
 *        Arduino/MPU6000, vía Raspberry Pi y websockets hacia webserver.
 * 
 * ii5c [-A 0|1|2|3] [-G 0|1|2|3] [-F 31.25-8000][-m|-g] [-d|-r|-f]\n\n",
 * -A         Fondo de escala del acelerómetro: 0 (2g), 1 (4g),"
 *            2 (8g), 3 (16g).\n"
 * -G         Fondo de escala del giróscopo: 0 (250 º/s), 1 (500 º/s),\n"
 *            2 (1000 º/s), 3 (2000 º/s).\n"
 * -F         Frecuencia de muestreo interna del MPU (31.25 a 8000).\n"
 *            Seguramente, distinta de la del dispositivo.\n"
 * -m|-g      m/(s*s) o g (9.8 m/(s*s))\n"
 * -d|-r|-f [º/s] o [rad/s] o [Hz]\n");
 * -l [Dispositivo USB]   para "cu -l dev"         <not implemented yet>
 * -s [velocidad del canal serie] para "cu -s" <not implemented yet>
 * 
 * Ejemplo:
 * 
 * Autor: César Llamas Bello, 2015
 *            PerComp - UVa.
 ***************************************************************************/

/***************************************************************************
 * El programa interactua mediante el mandato cu, que se encarga de la
 * entrada y salida a bajo nivel. Mediante el, le envía los parámetros de
 * configuración del dispositivo de sensorización y se encarga de
 * recibir los datos de salida codificados y los imprime en formato flotante
 * ya normalizados según los parámetros de muestreo especificados.
 **************************************************************************/

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <ctype.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <libgen.h>
#include <getopt.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <math.h>

#ifdef _WIN32
#define random rand
#endif

#ifdef CMAKE_BUILD
#include "lws_config.h"
#endif

static char *nombre = "IDUS-24-04-2015";

#include "libwebsockets.h"

/*******************************************************
************************** DEFINES GUAIS DE DEPURACION * 
*******************************************************/
#define UNUSED(x) (void)(x)

#define DEPURACION_0

#ifdef DEPURACION_0
#define DEP_0(x) (void) printf("\nDEP-0 [%s]%s:",funName,(x));fflush(stdout);
#else
#define DEP_0(x) ;
#endif

#define DEPURACION_1

#ifdef DEPURACION_1
#define DEP_1(x) (void)printf("\n\tDEP-1 [%s]%s:",funName,(x));fflush(stdout);
#else
#define DEP_1(x) ;
#endif

#define DEPURACION_2

#ifdef DEPURACION_2
#define DEP_2(x) (void)printf("\n\t\tDEP-2 [%s]%s:",funName,(x));fflush(stdout);
#else
#define DEP_2(x) ;
#endif

/*#####################
 * Variable de flujo de estado del GUI de entrada web.
 * IDLE: sin hacer nada.
 * READING: leyendo del Arduino, mediante dos procesos intermedios:
 *          el "proceso lector" hijo del actual interactúa con el proceso
 *          "cu" que es el que sondea el canal serie del arduino.
 *          El proceso lector es el que envía los datos al archivo de datos.
 * IDLE:    esperando las acciones de lectura.
 *          El diagrama de estado está en la cabecera del web_event_handler(),
 *          que es invocado por el servidor web embebido "mongoose",
 *          quien lleva la cuenta de la interacción desde el dispositivo
 *          móvil (o pc) que sirve de interfaz de usuario de alto nivel con
 *          la plataforma de sensorización.
 */
static enum EstadoProceso
        { IDLE, READING_READ, READING_WAIT, ERROR } estadoProceso = IDLE;

/**
 * Cada proceso tiene su bucle de salida.
 * (SIGINT) (^C) afecta al bucle Web, y 
 * (SIGUSR1)       afecta al bucle de lectura dataDump.
 * Como el manejador de señales es único, debe contemplar los dos casos :D
 */
static int keepRunningWeb  = -1; /* true */
static int keepRunningDump = -1; /* true */

#define EXIT_STATUS_OK      0 /* sin error */
#define EXIT_FAIL_ARGMNT    1 /* fallo en argumentos */
#define EXIT_FAIL_FORK      2 /* fallo en fork */
#define EXIT_FAIL_SHMEM     3 /* fallo en memoria compartida */
#define EXIT_FAIL_CANAL     4 /* fallo en E/S (dup2 o pipe) */
#define EXIT_FAIL_EXEC      5 /* fallo en la aplicación del execvp(el cu o lo que sea) */
#define EXIT_FAIL_FOPEN     6 /* fallo en la apertura/creación de archivo */

static int exit_status = EXIT_STATUS_OK;
                  /* siempre viene bien para salidas por la vía rapida */

/* indicadores de procesos */
pid_t pLector = 0;

/********************************************************
*************************************** WEBSOCKETS DEFS *
********************************************************/
static unsigned int opts;
static int se_cerro;  /* lo uso al marcar cierre del websock desde el server */

static int deny_deflate;
static int deny_mux;
static struct libwebsocket *wsi_mirror;
static int mirror_lifetime = 0;
static volatile int force_exit = 0;
static int longlived = 0;

#define ARCHIVIN "./datos.dat"      /* archivo a transferir (nombre) */
#define CANTIDAD    1024L          /* cant. de bytes a transferir cada envío */
static char *nombreArchivo = ARCHIVIN;
static FILE *fdatos = NULL;
static long int ifdatos   = 0;     /* numero de frag. a enviar a continuacion */
static long int nfdatos   = 0;     /* datos que quedan por transferir */
static long int tfdatos   = CANTIDAD; /* datos a transferir en cada envio */

static int websockeservertID = 0;  /* int que le da el server a este cliente */
/*
 *  RaspiToPC-protocol:  we connect to the server and print the primitive
 *            we are given
 */

enum mis_protocolos {

   PROTOCOLO_SENSORES,

   /* always last */
   DEMO_PROTOCOL_COUNT
};

/*************************************************************************
********************************************************** DATADUMP DEFS *
*************************************************************************/
/*####################
 * Comunicación proceso main() y proceso lectorMain().
 */
/* talla de la memoria compartida que se necesita para el siguiente catálogo */
#define SHMSZ    37
/* STATUS del proceso de lectura para el gestor de señales del webserver cuando
 * se elige CHECK */
#define SIDLE     "IDLE"             /* el sensor no ha sido utilizado aún */
#define SERRFORK  "ERROR-FORK"       /* error en el fork de lectorMain() */
#define SERRCANAL "ERROR-CANAL"      /* error en la creación de streams y dup2() */
#define SERREXEC  "ERROR-EXEC"       /* error en el exec del cu */
#define SREADY    "READY"            /* preparado para leer */
#define SACQUIRE  "ACQUIRE"          /* leyendo datos */
#define SPAUSE    "PAUSE"            /* pausa en la lectura */
/* ORDENES del webserver hacia el proceso de lectura, que afectan a la adquisición
 * de datos de Arduino. */
#define DORESUME  "DORESUME"         /* pedir a Arduino leer datos */
#define DOPAUSE   "DOPAUSE"          /* pedir a Arduino parar la lectura */
#define DOSTOP    "DOSTOP"           /* corta la lectura de Arduino */
#define TRANSITO  "TRANSITO"         /* valor transitorio tras pedir a Arduino una acción */

/* Puntero a la memoria compartida entre el WebServer y el intHandler
 * contiene uno de los mensajes anteriores.
 * Cuando no está activo lectorMain() debe ser "IDLE".
 * Se reserva su memoria en main().
 * http://stackoverflow.com/questions/230062/whats-the-best-way-to-check-if-a-file-exists-in-c-cross-platform
 */
char *shm;
/* para comunicar en la memoria compartida */
#define comSHM(x)   strcpy(shm, (x))

/*######################
 * Parámetros de la sensorización y lectura de datos.
 */
/* Estructura que sustenta los parámetros de adquisición de los sensores */
struct SensParm {
    float fMuestreo;  /* frecuencia de muestreo */
    unsigned int iMuestreo;
                      /* configuración del registro de la IMU para la
                       * frecuencia fMuestreo anterior */
    char *modoAcc ;   /*(+-2g)*/
    char *modoGyr ;   /*(+-250º/s)*/
    char *sRate    ;  /*(100 muestras/s)*/
    int c;
    int unidadesAcc;  /* 0: g, 1: m/(s*s) */
    int unidadesGyr;  /* 0: º/s, 1: rad/s, 2: Hz */
    /*********
     * sensParm struct initialization
     ********/

    char *uAceleracion;
    char *uGiroscopo;

    /* para la sensibilidad del acelerometro de MPU6000
    *   por defecto en g */
    float normaA;

    /* para la sensibilidad del giroscopo de MPU6000
    *   por defecto en º/s */
    float normaG;

    /* para la frecuencia de muestreo del MP6000
    *   por defecto en Hz.
    */
    float Rate;
} sensParm ;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Method declaration section
 *~~~~~~~~~~~~~~~~~~~~~~~~~~*/
int dataDump(FILE *, FILE *, const char*);
int lectorMain();
void goRead();
void goWait();
void goStop();
void goResume();

unsigned int hexa2binInt(unsigned char c) ;
unsigned int hexa2binShort(unsigned char c) ;
short aCorto(unsigned char *s) ;
unsigned int aInt(unsigned char *s) ;
char * printFecha(char *) ;
void ayuda(char *) ;

#include "./funciones/loggeo.c"

/*************************************************************************
*************************************************************** END DEFS *
*************************************************************************/

/*********************************
* callback_protocolo_sensores.
*/

static int
callback_protocolo_sensores(struct libwebsocket_context *context,
                            struct libwebsocket *wsi,
                            enum libwebsocket_callback_reasons evento,
                            void *user, void *in, size_t len) {
   char * funName = "callback_protocolo_sensores";
   extern int pLector;

   unsigned char buf[LWS_SEND_BUFFER_PRE_PADDING + 4096 +
                     LWS_SEND_BUFFER_POST_PADDING];
   int nbytes_netos    = 0;
   int nbytes_enviados = 0;

   switch (evento) {
   case LWS_CALLBACK_CLIENT_ESTABLISHED:
      fprintf(stderr, "callback_protocolo_sensores: LWS_CALLBACK_CLIENT_ESTABLISHED\n");
      fprintf(stderr, "Saludo inicial...\n"); fflush(stderr);
     /*
      * start the ball rolling,
      * LWS_CALLBACK_CLIENT_WRITEABLE will come next service
      */
      nbytes_netos    = sprintf((char *)&buf[LWS_SEND_BUFFER_PRE_PADDING],
                                "/saludo %s", nombre);
      nbytes_enviados = libwebsocket_write(wsi,
         &buf[LWS_SEND_BUFFER_PRE_PADDING], nbytes_netos, opts | LWS_WRITE_TEXT);

      printf("saludo enviado\n"); fflush(stdout);
      /*
      if (nbytes_enviados < 0)
         return -1;
      if (nbytes_enviados < nbytes_netos) {
         lwsl_err("Escritura parcial LWS_CALLBACK_CLIENT_WRITEABLE\n");
         return -1;
      }
      */
      fprintf(stderr, "Esperando peticiones del pc\n"); fflush(stderr);

      break;

   case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
      fprintf(stderr, "LWS_CALLBACK_CLIENT_CONNECTION_ERROR\n");
      se_cerro = 1;
      break;

   case LWS_CALLBACK_CLOSED:
      fprintf(stderr, "LWS_CALLBACK_CLOSED\n");
      se_cerro = 1;
      break;

   case LWS_CALLBACK_CLIENT_RECEIVE:
      fprintf(stderr, "rx %d '%*s'\n", (int)len, (int) len, (char *)in);
      fflush(stderr);

 /*RET00*/
      if (len >= 5 && !memcmp(in, "RET00", 5)) {    /* respuesta de /saludo */
         *((char *)in+len)='\0'; /* construye un NTS */
         sscanf((char *) in + 5, "%d", &websockeservertID);
         printf("El identificador del servidor es: %d\n", websockeservertID);
 /*FILE-*/
      /* Aquí hay que procesar FILE-
       * 1º enviar FILE con /06 talla blocksize
       * 2º esperar /RET60 (archivo abierto listo para recibir)
       *          o /RET61 (error leyendo parametros de transferencia)
       */
      } else if (len >= 5 && !memcmp(in, "FILE-", 5)) {        /* -> /06 */
        struct stat infoFile;

        printf("Hay que abrir el archivo\n"); fflush(stdout);
        if (fdatos || (fdatos = fopen(nombreArchivo, "rb"))) {
          fstat(fileno(fdatos), &infoFile);
          nfdatos = infoFile.st_size;
          tfdatos = CANTIDAD;
          printf("Fichero abierto para enviar %d bytes\n", (int) nfdatos);
        } else {
          printf("Imposible abrir archivo\n");
          return -1;
        }


        nbytes_netos    = sprintf((char *)&buf[LWS_SEND_BUFFER_PRE_PADDING],
                                  "/06 %ld %ld", nfdatos, CANTIDAD);
        nbytes_enviados = libwebsocket_write(wsi,
           &buf[LWS_SEND_BUFFER_PRE_PADDING],
           nbytes_netos, opts | LWS_WRITE_TEXT);

 /*RET60*/
      } else if (len >= 5 && !memcmp(in, "RET60", 5)) { /* /06 -> */
         printf("Invocado el OK para empezar a enviar datos\n");

         tfdatos = (tfdatos < nfdatos ) ? tfdatos : nfdatos;

         if (tfdatos != fread((void *) buf+LWS_SEND_BUFFER_PRE_PADDING,
                            1, tfdatos, fdatos)) {
            printf("Imposible leer datos\n");
         }
         nbytes_enviados = libwebsocket_write(wsi,
                    &buf[LWS_SEND_BUFFER_PRE_PADDING],
                    tfdatos, opts | LWS_WRITE_BINARY);

         nfdatos -= tfdatos;
         ifdatos++;
         if (nfdatos <= 0) {
            fclose(fdatos);
            fdatos  = NULL ;
            nfdatos = 0;
            ifdatos = 0;
         } else {
            libwebsocket_callback_on_writable(context, wsi);
         }
 /*RET61*/
      } else if (len >= 5 && !memcmp(in, "RET61", 5)) { /* /06 -> */
         printf("El PC no esta listo para recibir datos\n"); fflush(stdout);
         nfdatos = 0;
         fclose(fdatos);
         ifdatos = 0;
 /*START*/
      } else if (len >= 5 && !memcmp(in, "START", 5)) {
         /* -> /00  si todo va bien y -> /10 si hay un problema en el  fork() */
         /*       and START go READING/READ
          *                 do { startReading();
          *                      goRead();  }
          *                 output "status" 
          */
          {
            int retornoLector; /* variable para el proceso hijo (case 0) */
            switch (pLector=fork()) {
            case 0: // hijo: proceso lector del Arduino
                 switch (retornoLector = lectorMain()) { /* al log de error */
                        /* lectorMain() al ponerse en marcha hace un startReading()
                         * y un goRead() por defecto, por intermediación de
                         * dataDump(). Si no puede, devuelve error.
                         */
                  case EXIT_STATUS_OK:  /* preparado para ampliaciones */
                       DEP_0("lectorMain olrait!");
                       DEP_0(shm);
                       break;
                  case EXIT_FAIL_CANAL:
                  case EXIT_FAIL_EXEC:
                  case EXIT_FAIL_FORK:
                       DEP_0("lectorMain fallido");
                       DEP_0(shm);
                       break;
                 }
                 exit(retornoLector);
                 break;
             case -1: // fallo
                 /* fallo en el fork */
                 exit_status = EXIT_FAIL_FORK;
                 keepRunningWeb = 0;
                 /* caratula(conn, "STATUS: E-Arrancando: fork fallido.");
                  * cambiado por: */
                 nbytes_netos    = sprintf((char *)&buf[LWS_SEND_BUFFER_PRE_PADDING],
                        //"/10 %ld %ld", nfdatos, CANTIDAD);
                        "/10");
                 nbytes_enviados = libwebsocket_write(wsi,
                         &buf[LWS_SEND_BUFFER_PRE_PADDING],
                         nbytes_netos, opts | LWS_WRITE_TEXT);
                 break;
             default: // padre: hilo actual del main web.
                 estadoProceso = READING_READ;
                 DEP_0("estadoProceso=READING_READ");
                 /* caratula(conn, "STATUS: OK: Arrancado.");
                  * cambiado por: */
                 nbytes_netos    = sprintf((char *)&buf[LWS_SEND_BUFFER_PRE_PADDING],
                        //"/00 %ld %ld", nfdatos, CANTIDAD);
                        "/00");
                 nbytes_enviados = libwebsocket_write(wsi,
                         &buf[LWS_SEND_BUFFER_PRE_PADDING],
                         nbytes_netos, opts | LWS_WRITE_TEXT);
            }
          }
          break;
      } else if (len >= 5 && !memcmp(in, "STOP-", 5)) {
          /* -> /01 */
          /*      and STOP  go IDLE
           *                do { goWait();
           *                     stopReading();
           *                     check(); }
           *                output "status"
           */
           goStop();
           /* espero que en un segundo haya parado Arduino */
           while (strcmp(shm, SPAUSE) && strcmp(shm, SIDLE))
             sleep(1);

            /* Trata de desembarazarse del proceso Lector */
           int proc_status;

           /* Matar el proceso lector desencadena la muerte del proceso cu también */
           kill(pLector, SIGUSR1);
           while (wait(&proc_status) != -1) ; /* pick up dead children (proces lector) */
           pLector=0;
           estadoProceso = IDLE;
           DEP_0("estadoProceso=IDLE");
           DEP_0(shm);
           /* caratula(conn, "STATUS: OK: Lector parado.");
            * cambiado por: */
           nbytes_netos    = sprintf((char *)&buf[LWS_SEND_BUFFER_PRE_PADDING],
                 //"/01 %ld %ld", nfdatos, CANTIDAD);
                 "/01");
           nbytes_enviados = libwebsocket_write(wsi,
                  &buf[LWS_SEND_BUFFER_PRE_PADDING],
                  nbytes_netos, opts | LWS_WRITE_TEXT);
           break;
      } else if (len >= 5 && !memcmp(in, "PAUSE", 5)) { /* -> /02 */
           goWait();
           DEP_0("estadoProceso=WAIT");
           estadoProceso = READING_WAIT;
           nbytes_netos    = sprintf((char *)&buf[LWS_SEND_BUFFER_PRE_PADDING],
                 "/02");
           nbytes_enviados = libwebsocket_write(wsi,
                  &buf[LWS_SEND_BUFFER_PRE_PADDING],
                  nbytes_netos, opts | LWS_WRITE_TEXT);
           break;
      } else if (len >= 5 && !memcmp(in, "RESUM", 5)) { /* -> /03 */
           if (estadoProceso == READING_WAIT) {
           goResume();
           DEP_0("estadoProceso=START");
           estadoProceso = READING_READ;
           nbytes_netos    = sprintf((char *)&buf[LWS_SEND_BUFFER_PRE_PADDING],
                 "/03");
           nbytes_enviados = libwebsocket_write(wsi,
                  &buf[LWS_SEND_BUFFER_PRE_PADDING],
                  nbytes_netos, opts | LWS_WRITE_TEXT);
           }
           break;
      } else if (len >= 5 && !memcmp(in, "RESET", 5)) { /* -> /04 */
      } else if (len >= 5 && !memcmp(in, "DATOS", 5)) { /* -> /05 */
      } else {  /* -> /10 */
         printf("Mandato de la Raspi no conocido\n"); fflush(stdout);
        return -1;
      }
      break;

   case LWS_CALLBACK_CLIENT_WRITEABLE:
     /* printf("---%ld,\t", nfdatos); fflush(stdout); */
     /* si fdatos != NULL es que se esta dando una transferencia.
      */
     if (fdatos) {
         tfdatos = (tfdatos < nfdatos ) ? tfdatos : nfdatos;
         if (tfdatos != fread((void *) buf + LWS_SEND_BUFFER_PRE_PADDING,
                            1, tfdatos, fdatos)) {
            printf("Imposible leer datos\n");
         }
         nbytes_enviados = libwebsocket_write(wsi,
                    &buf[LWS_SEND_BUFFER_PRE_PADDING],
                    tfdatos, opts | LWS_WRITE_BINARY);

         nfdatos -= tfdatos;
         ifdatos++;
         if (nfdatos <= 0) {
            fclose(fdatos);
            fdatos  = NULL ;
            nfdatos = 0;
            ifdatos = 0;
         } else {
            libwebsocket_callback_on_writable(context, wsi);
         }
     }
     break;

   /* si somos el primer elemento de protocolos[0] ... */
   case LWS_CALLBACK_CLIENT_CONFIRM_EXTENSION_SUPPORTED:
      if ((strcmp(in, "deflate-stream") == 0) && deny_deflate) {
         fprintf(stderr, "denied deflate-stream extension\n");
         return 1;
      }
      if ((strcmp(in, "deflate-frame") == 0) && deny_deflate) {
         fprintf(stderr, "denied deflate-frame extension\n");
         return 1;
      }
      if ((strcmp(in, "x-google-mux") == 0) && deny_mux) {
         fprintf(stderr, "denied x-google-mux extension\n");
         return 1;
      }
      break;

   default: break;
   }

   return 0;
}


/* list of supported protocols and callbacks */

static struct libwebsocket_protocols protocolos[] = {
   {
      "RaspiToPC-protocol, proprietary-sensoring-protocol",
      callback_protocolo_sensores,
      0,
      4096
   },
   { NULL, NULL, 0, 0 } /* end */
};

/* void sighandler(int sig)
{
   force_exit = 1;
}*/
/**************************************************************************
 * intHandler() es invocado en el proceso lector de datos del sensor
 * a causa de * algún kill en el proceso controlador de la interfaz.
 */
void intHandler(int sig) {
  char * funName = "intHandler";

    /**
     * Cada proceso tiene su bucle de salida.
     * (SIGINT)  (^C) afecta al bucle Web, y 
     * (SIGUSR1)  afecta al bucle de lectura de volcado de datos del
     *            "proceso lector", que en este caso se encarga de .
     * Como el manejador de señales es único, debe contemplar los dos casos :D
     */
      if (sig == SIGUSR1)
         keepRunningDump = 0; /* false: stop lectura */
      else {
         if (READING_READ == estadoProceso || READING_WAIT == estadoProceso) {
            /* Trata de desembarazarse del proceso Lector */
            int proc_status;

      /* Matar el proceso lector desencadena la muerte del proceso cu también */
            //kill(pLector, SIGUSR1);
            kill(pLector, SIGINT);
            while (wait(&proc_status) != -1);
                  /* pick up dead children (proces lector) */
         }
         keepRunningWeb = 0; /* false: stop todo */
      }
}

/**************************************************************************
 * main()
 *****************/
int main(int argc, char **argv) {
   char * funName = "main";

   int ret = 0;
   int port = 80;
   int use_ssl = 0; /* sin ssl */
   struct libwebsocket_context *context;
   const char *address = "192.168.0.16";
   struct libwebsocket *wsi_elPC;
   int ietf_version = -1; /* latest */

   /* para enviar el primer mensaje */
   unsigned char buf[LWS_SEND_BUFFER_PRE_PADDING + 4096 +
                     LWS_SEND_BUFFER_POST_PADDING];
   int nbytes_netos    = 0;
   int nbytes_enviados = 0;

   fprintf(stderr, "Cliente de libwebsockets on Raspberry-pi\n");

   signal(SIGINT,  intHandler);
   signal(SIGUSR1, intHandler);

   /*
    * create the websockets context.  This tracks open connections and
    * knows how to route any traffic and which protocol version to use,
    * and if each connection is client or server side.
    *
    * For this client-only demo, we tell it to not listen on any port.
    */
   struct lws_context_creation_info info;
   memset(&info, 0, sizeof info);

   info.port = CONTEXT_PORT_NO_LISTEN;
   info.protocols = protocolos;
#ifndef LWS_NO_EXTENSIONS
   info.extensions = libwebsocket_get_internal_extensions();
#endif
   info.gid = -1;
   info.uid = -1;

/*********************************************************
**********************************************************
************** BEGIN MONGOMAIN ***************************
**********************************************************
*********************************************************/
    /****************************
     * #Preamble.
     *      * Log preparations
     *      * Sensor declaration
     *      * getopt() decoding
     *      * shared memory initialization
     *      * web service initialization
     *      * sensParm struct initialization
     *      * dataFile struct initialization
     ****************************/
    /*********
     * Log preparations
     */
    if (!logInit()) {
         perror("Inicialización del log");
         exit_status = EXIT_FAIL_FOPEN; /* fallo en apertura de fichero */

         return exit_status;
    }

    /*********
     * Sensor declarations
     ********/
    extern struct SensParm sensParm;
          sensParm.modoAcc         = "0";    /*(+-2g)*/
          sensParm.modoGyr         = "0";    /*(+-250º/s)*/
          sensParm.sRate            = "100"; /*(100 muestras/s)*/
          sensParm.unidadesAcc   = 0; /* 0: g, 1: m/(s*s) */
          sensParm.unidadesGyr   = 0; /* 0: º/s, 1: rad/s, 2: Hz */
          sensParm.uAceleracion = "g";
          sensParm.uGiroscopo    = "º/s";

          /* para la sensibilidad del acelerometro de MPU6000
          *   por defecto en g */
          sensParm.normaA          = 1.0;

          /* para la sensibilidad del giroscopo de MPU6000
          *   por defecto en º/s */
          sensParm.normaG          = 1.0;

          /* para la frecuencia de muestreo del MP6000
          *   por defecto en Hz.
          */
          sensParm.Rate             = 100.0;

    opterr = 0;

    /*******************
     * getopt decoding
     *******************/
    int c;
    while ((c = getopt (argc, argv, "rdfgmF:A:G:")) != -1)
       switch (c) {
          /*   Variables de la adquisición de los datos */
          case 'A':
             sensParm.modoAcc = optarg;
             break;
          case 'G':
             sensParm.modoGyr = optarg;
             break;
          case 'F':
             sensParm.sRate = optarg; break ;
          /*   Unidades de medida de los datos adquiridos */
          case 'g':   /* g */
             sensParm.normaA = 1.0;
             sensParm.uAceleracion = "g";
             break;
          case 'm':   /* m/s^2 dado g */
             sensParm.normaA = 1.0/9.8;
             sensParm.uAceleracion = "m/s^2";
             break;
          case 'd':   /* Degrees/s - º/s */
             sensParm.normaG = 1.0;
             sensParm.uGiroscopo    = "º/s";
             break;
          case 'f':   /* Frequency-Hz   dado º/s */
             sensParm.normaG = 1.0/360.0;
             sensParm.uGiroscopo    = "Hz";
             break;
          case 'r':   /* Angle-rad/s dado º/s*/
             sensParm.normaG = M_PI/180.0;
             sensParm.uGiroscopo    = "rad/s";
             break;
          case '?':
             if (optopt == 'c') {
                fprintf (stderr,
                    "La opción -%c requiere 2g, 4g, 8g o 16g.\n", optopt);
             } else if (isprint (optopt)) {
                fprintf (stderr, "Opción desconocida `-%c'.\n", optopt);
                ayuda(argv[0]);
             } else {
                fprintf (stderr,
                    "Caracter de opción, desconocido`\\x%x'.\n", optopt);
                ayuda(argv[0]);
             }
             exit_status = EXIT_FAIL_ARGMNT ; /* fallo en argumentos */
             return exit_status ;
          default:
             /* this must never be reached */
             abort ();
    }

    /*********
     * Shared memory to comm status of adquisition.
     ********/
    /* Antes de crear los pipes vamos a crear una zona de memoria
     * compartida para el webServerHandler y el proceso escritor
     * del archivo de adquisición. (http://www.cs.cf.ac.uk/Dave/C/node27.html)
     */
    int shmid;
    /* Nombre de nuestro segmento de memoria. "5678". */
    key_t key = 5678;
    /* Create the segment. */
    if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
       perror("shmget");
       exit_status = EXIT_FAIL_SHMEM; /* fallo en memoria compartida */
       return exit_status;
    }

    /* Now we attach the segment to our data space. */
    if ((shm = shmat(shmid, NULL, 0)) == (char *) -1) {
       perror("shmat");
       exit_status = EXIT_FAIL_SHMEM; /* fallo en memoria compartida */
       return exit_status;
    }
    comSHM(SIDLE);

    /********
     * Signal handler. (seccion modificada)
     *******/
     /* signal(SIGINT, intHandler); */
            /* Señal de interrupción lanzada desde un terminal, por ejemplo */
     /* signal(SIGUSR1, intHandler); */
            /* Señal lanzada desde el gestor del WebServer */

    /*********
     * Web service declarations. (seccion modificada)
     ********/
     /*
    struct mg_server *server = mg_create_server(NULL, web_event_handler);
    mg_set_option(server, "document_root", ".");
    mg_set_option(server, "listening_port", "8080");
     */


    /*********
     * sensParm struct initialization
     ********/

    /* Valores de normalización para el acelerómetro de InvenSense MPU6000,
    *   en función de la precisión del dato recibido
    *         float fMuestreo = atof(sRate);
    *   en el programa del controlador.
    */
    switch (sensParm.modoAcc[0]) {
      case '0': sensParm.normaA *= 16384.0; break;
      case '1': sensParm.normaA *= 8192.0;   break;
      case '2': sensParm.normaA *= 4096.0;   break;
      case '3': sensParm.normaA *= 2048.0;   break;
      default:
         ayuda(argv[0]);
         exit_status = EXIT_FAIL_ARGMNT; /* fallo en argumentos */
         return exit_status;
    }

    /* Valores de normalización para el giróscopo de InvenSense MPU6000,
    *   en función de la precisión del dato recibido. Debe coincidir
    *   con el valor indicado en el programa del controlador.
    */
    switch (sensParm.modoGyr[0]) {
      case '0': sensParm.normaG *= 131.0;  break;
      case '1': sensParm.normaG *= 65.5;   break;
      case '2': sensParm.normaG *= 32.8;   break;
      case '3': sensParm.normaG *= 16.4;   break;
      default:
         ayuda(argv[0]);
         exit_status = EXIT_FAIL_ARGMNT; /* fallo en argumentos */
         return exit_status;
    }

    /* Frecuencia de adquisición de datos para el giróscopo de
     * InvenSense MPU6000. Admite más, pero para nuestra configuración con
     * hasta 6 sensores, en Arduino soporta hasta 100 muestras por segundo
     * de cada sensor giróscopo y acelerómetro.
     * en total son: 100 x 6 x 2 x 3 = 3600 enteros por segundo.
     *   
     * de la pág. 12 del libro de Registros: la tasa de salida del
     * acelerómetro es fija de 1kHz.
     * La tasa de muestreo global viene entonces limitada por la tasa de
     * salida del giróscopo.
     * La tasa de salida del giróscopo es 8kHz con cierto filtro DLPF
     * desabilitado, y 1kHz con el filtro habilitado.
     * En nuestro caso estará deshabilitado, con lo que la tasa de muestreo
     * global se calcula con la siguiente fórmula:
     * Tasa Muestreo = [Tasa de salida del giróscopo]/(1 + SMPLRT_DIV)
     *               = 8000 / (1 + SMPLRT_DIV)
     *    SMPLRT_DIV = (8000 / Tasa_Muestreo ) - 1
     *               = (Divisor de la tasa de muestreo).
     * en función de la precisión del dato recibido. Debe coincidir
     * con el valor indicado en el programa del controlador.
     */

    sensParm.fMuestreo = atof(sensParm.sRate);
    sensParm.iMuestreo = (unsigned int) ((8000.0 / sensParm.fMuestreo) - 1.0);

    if (sensParm.fMuestreo < 31.25 || sensParm.fMuestreo > 8000.0) {
       ayuda(argv[0]);
       exit_status = EXIT_FAIL_ARGMNT;
       /* fallocaratula(conn, "STATUS: OK: Proceso leyendo."); en argumentos */
       return exit_status;
    }

    /* Depuración para comprobar valores
    printf("ModoAcelerometro = %c, ModoGiroscopo = %c, iMuestreo = %u\n",
               modoAcc[0], modoGyr[0], iMuestreo);
    printf("%f, %f, %f\n", fMuestreo, normaA, normaG);
    */

    /*********
     * dataFile struct initialization, con nuestros valores por defecto.
     * Con ellos se inicializará cuando sea necesario el nombre del archivo
     * con initFileName()

    extern struct DataFile dataFile;
    strcpy(dataFile.nombrePath, "./");
    strcpy(dataFile.nombreBase, "archivo");
    strcpy(dataFile.extension,  ".datos");
    initFileName();
     ********/

    /****************************
     * #Main Loop.
     *      Es en esencia un bucle de servicio web.
     ***************************/
    DEP_0("Entrando en bucle de servicio Web");
    DEP_0("estadoProceso=IDLE");



/*********************************************************
**********************************************************
************** END MONGOMAIN *****************************
**********************************************************
*********************************************************/
   context = libwebsocket_create_context(&info);
   if (context == NULL) {
      fprintf(stderr, "Creación fallida del contexto libwebsocket\n");
      return 1;
   }

   /* create a client websocket using RaspiToPC-protocol */

   wsi_elPC = libwebsocket_client_connect(context, address, port, use_ssl,
         "/", "localhost", "localhost", /* argv[optind], argv[optind], */
          protocolos[PROTOCOLO_SENSORES].name, ietf_version);

   if (wsi_elPC == NULL) {
      fprintf(stderr, "libwebsocket conexión con PC fallido\n");
      ret = 1;
   } else {
      /* sit there servicing the websocket context to handle incoming
       * packets,.... nothing happens until the client websocket connection is
       * asynchronously established
       */
      int n = 0;

    /****************************
     * #Main Loop.
     *      Es en esencia un bucle de servicio web.
     ***************************/
    DEP_0("Entrando en bucle de servicio Web");
    DEP_0("estadoProceso=IDLE");

      while (n >= 0 && !se_cerro && keepRunningWeb) {
         n = libwebsocket_service(context, 1);

         if (n < 0)
            continue;
      }
   }

   fprintf(stderr, "Exiting\n");

   libwebsocket_context_destroy(context);

    /* hay que matar al poceso lector si es que estuviera activo !!*/
    if (pLector == 0) {
       /* y luego esperar por él */
       int proc_status;

       kill(pLector, SIGUSR1);

       /* pick up dead children (proces lector) */
       while (wait(&proc_status) != -1) ;
    }


   return exit_status;
   /* en lugar de return ret ; */
}

#include "./funciones/dataDump-supersoft.c"
#include "./funciones/aCorto.c"
#include "./funciones/lectorMain.c"
#include "./funciones/printFecha.c"
#include "./funciones/hexa2binInt.c"
#include "./funciones/hexa2binShort.c"
#include "./funciones/ayuda.c"
#include "./funciones/aInt.c"
#include "./funciones/goWait.c"
#include "./funciones/goRead.c"
#include "./funciones/goResume.c"
#include "./funciones/goStop.c"
